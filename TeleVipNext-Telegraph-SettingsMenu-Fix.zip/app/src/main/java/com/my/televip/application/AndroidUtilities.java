package com.my.televip.application;

import android.os.Handler;

import com.my.televip.logging.Logger;
import com.my.televip.utils.Utils;

public class AndroidUtilities {

    public static float density = 1;

    public static volatile Handler applicationHandler;

    public static void runOnUIThread(Runnable runnable) {
        if (applicationHandler == null) {
            return;
        }
        applicationHandler.post(runnable);

    }

    public static void init() {
        try {
            applicationHandler = new Handler(ApplicationLoaderHook.getApplicationContext().getMainLooper());
            density = Utils.getCurrentActivity().getResources().getDisplayMetrics().density;
        } catch (Throwable e) {
            Logger.e(e);
        }
    }

    public static int dp(float value) {
        if (value == 0) {
            return 0;
        }
        return (int) Math.ceil(density * value);
    }

}
